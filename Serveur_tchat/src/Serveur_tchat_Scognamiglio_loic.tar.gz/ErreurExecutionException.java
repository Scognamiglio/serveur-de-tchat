
public class ErreurExecutionException extends Exception {
	public ErreurExecutionException(String msg){
		super(msg);
	}
}
