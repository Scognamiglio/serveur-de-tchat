
public class ErreurDeSyntaxeException extends Exception {
	public ErreurDeSyntaxeException(String msg){
		super(msg);
	}

}
